import sqlite3
from tkinter import *
master = Tk()

def setupdbAndTable():
    with sqlite3.connect("UserData.db") as db:
        cursor = db.cursor()
        sql = """
                CREATE TABLE IF NOT EXISTS UserNamePassword
                (UserID INTEGER PRIMARY KEY,
                Username TEXT,
                Password TEXT);
              """
        cursor.execute(sql)
def createPermissionsTable():
    with sqlite3.connect("UserData.db") as db:
        cursor = db.cursor()
        sql = """
                CREATE TABLE IF NOT EXISTS Permissions
                (PermissionsID INTEGER PRIMARY KEY,
                UserID INTEGER,
                Permissions TEXT,
                FOREIGN KEY(UserID) REFERENCES UserNamePassword(UserID));
              """
        cursor.execute(sql)
def setupCipTable():
    with sqlite3.connect("UserData.db") as db:
        cursor = db.cursor()
        sql = """
                CREATE TABLE IF NOT EXISTS CipherData
                (CipherID INTEGER PRIMARY KEY,
                UserID INTEGER,
                CipherText TEXT,
                CipherType TEXT,
                RVal INT,
                FOREIGN KEY(UserID) REFERENCES UserNamePassword(UserID));
              """
        cursor.execute(sql)
def setupAccoAcceTable():
    with sqlite3.connect("UserData.db") as db:
        cursor = db.cursor()
        sql = """
                CREATE TABLE IF NOT EXISTS AccoAcce
                (CipherID INTEGER PRIMARY KEY,
                UserID INTEGER,
                MMN TEXT,
                FPN TEXT,
                PIN INT,
                FOREIGN KEY(UserID) REFERENCES UserNamePassword(UserID));
              """
        cursor.execute(sql)
def Login():
    UserName = input("UserName: ")
    Password = input("Password: ")
def GetUNPD():
   pass

def signUp(E1,E2):
    with sqlite3.connect("UserData.db") as db:
        UN = E1.get()
        Pd = E2.get()
        Pd = hash(Pd)
        Values = (UN, Pd)

        sql = """
              INSERT INTO UserNamePassword
              (UserName, Password)
              VALUES(?,?);
              """
        cursor.execute(sql, Values)

def Nope():
        Label(master, text = "Username", bg ="white", fg = "black").grid(row = 0)
        Label(master, text = "Password", bg ="white", fg = "black").grid(row = 1)
        
        E1 = Entry(master).grid(row = 0, column = 1)
        E2 = Entry(master, show = "*").grid(row = 1, column = 1)
        Button(master,text='Submit',command=signUp(E1,E2)).grid(row=4,column=0,sticky=W,pady=4)


def GetStuff():
    master.title("Mega\nincryptor")
    master.geometry("200x100")
    Button(master,text='Login',command=Login).grid(row=5,column=0,sticky=W,pady=4)
    Button(master,text='Sign Up',command=Nope).grid(row=7,column=0,sticky=W,pady=4)
    Button(master,text='Quit',command=master.destroy).grid(row=9,column=0,sticky=W,pady=4)

if __name__ == "__main__":
      GetStuff()





