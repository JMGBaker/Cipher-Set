import random
from Rot import Rot

class Vernam(Rot):
    def __init__(self, LCOrUC, ShiftVal = 0):
        super().__init__(LCOrUC, ShiftVal = 0)
        
        self.CipherKey = None
        self.Diff = 0
        self.cipherTextNoList = []
        self.cipherTextBinList = []
        self.OneTimePadList = []

    def GetPlainText(self, PlainText):
        self.plainText = PlainText
        return self.plainText

    def CreateNoList(self):
        for x in range(0, len(self.plainText)):
            for y in range(0, len(self.PlaintextAlphabet)):
                if self.plainText[x] == self.PlaintextAlphabet[y]:
                    self.CipherTextNoList.append(y)
        print(self.CipherTextNoList)
        for x in range(0, len(self.cipherTextNoList)):
            self.cipherTextBinList.append(bin(self.cipherTextNoList[x]))            
        return self.cipherTextBinList

    
    def OneTimePad(self):
        for x in range(0, len(self.cipherTextBinList)+random.randint(0, 10)):
            self.OneTimePadList.append(bin(random.randint(0, len(self.cipherTextBinList)+random.randint(0, 10))))
        return self.OneTimePadList

    
    def VernamCipher(self):
        while len(self.cipherTextBinList) != len(self.OneTimePadList):
            self.cipherTextBinList.append(bin(0))
        for x in range(0, len(self.OneTimePadList)):
            self.cipherTextList.append(self.cipherTextBinList[x]^self.OneTimePadList[x])
        return self.cipherTextList
    def FinishCipherText(self):
        for x in range(0, len(self.cipherTextList)):
            self.CipherText += self.PlaintextAlphabet[int(self.cipherTextList[x])]
        return self.CipherText
    def FinishCipherKey(self):
        for x in range(0, len(self.OneTimePadList)):
            self.CipherKey += self.PlaintextAlphabet[int(self.OneTimePadList[x])]
        return self.CipherKey
    
            
            

            
            
    
            
            
