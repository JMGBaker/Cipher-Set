from Language import language

class TranspositionCipher(Language):
    def __init__(self):
        super().__init__()
        self.__stepping = 0
        
    def setStepping(self, stepping):
        self.__stepping = stepping
    def getStepping(self):
        return self.__stepping 
    def setPlainText(self, PlainText):
        self.__plainText = PlainText
    def WordSplitter(self):
        L1 = self.__plaintext.split()
        L2 = []
        print(L1)
        for x in range(0, len(L1)):
            s = L1[x]
            for y in range(0, len(s)):
                L2.append(s[y])
                print(L2)
            self.__plainTextList.append(L2)
            L2 = []
        return self.__plainTextList
