class rot13(language):
    def __init__(self, LCOrUC):
        super().__init__()
        self.LCOrUC = LCOrUC
        self.rot13Alphabet = ["N","O","P","Q","R","S","T","U","V","W","X","Y","Z","A","B","C","D","E","F","G","H","I","J","K","L","M"]
        self.rot13LCAlphabet = ["n","o","p","q","r","s","t","u","v","w","x","y","z","a","b","c","d","e","f","g","h","i","j","k","l","m"]



    def makeCipherText(self):
        if self.LCOrUC == 1:
            for x in range(0, len(self.plainText)):
                for i in range(0, len(self.PlaintextAlphabet)):
                    if self.PlaintextAlphabet[i] == self.plainText[x]:
                        self.cipherTextList.append(self.rot13Alphabet[i])
                        break
        else:
            for x in range(0, len(self.plainText)):
                for i in range(0, len(self.PlaintextLCAlphabet)):
                    if self.PlaintextLCAlphabet[i] == self.plainText[x]:
                        self.cipherTextList.append(self.rot13LCAlphabet[i])
                        break
            

        return self.cipherTextList
    def CombineLetters(self):
        for x in range(0, len(self.cipherTextList)):
            self.CipherText += self.cipherTextList[x]
        return self.CipherText 
    
