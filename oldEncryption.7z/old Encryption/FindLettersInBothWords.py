import collections

e = "elephantine"
t = "tine"
eCounts = collections.Counter(e)
tCounts= collections.Counter(t)
