import random
from Language import Language
class newVernam(Language):
      def __init__(self, plainText):
            super().__init__()

            self.plainText = plainText
            self.ciphertext = ""
            self.spaceDef = []
            self.key = []
            self.pTL = []
            self.plainTextList  = []
            self.letterKey = ""
            self.FormatText()
      def FormatText(self):
            for x in self.plainText:
                  if x != " ":
                        self.pTL.append(x)
            self.createKey()
      def createKey(self):
            for x in range(0, len(self.pTL)):
                  self.key.append(random.randint(97,122))
            y = map(bin, self.key)
            self.key = y
            self.fullEncryption()
      def fullEncryption(self):
            self.spaceDef = self.spaceDefiner()
            nL = []
            for x in self.pTL:
                  nL.append(self.LCAlphaBet[x])
            r = []
            for x in range(0, len(0,nL)):
                  r.append(nL[x]^self.key[x])
            for x in range(0, len(r)):
                  if x not in spaceDef:
                        self.ciphertext += self.alphaBet[r[x]]
                  else:
                        self.ciphertext += " "
            for x in range(0, len(nL)):
                  if x not in spaceDef:
                        self.letterKey +=  self.alphaBet[nL[x]]
                  else:
                        self.ciphertext += " "              
            
            
            













                  
      
