import random
from Language import Language
class newVernam(Language):
      def __init__(self, plainText):
            super().__init__()
            self.LCAlphaBet = {
                  "!":bin(33),
                  "#":bin(35),
                  "$":bin(36),
                  "%":bin(37),
                  "&":bin(28),
                  "*":bin(42),
                  "+":bin(43),
                  ",":bin(44),
                  "-":bin(45),
                  ".":bin(46),
                  "/":bin(47),
                  "0":bin(48),
                  "1":bin(49),
                  "2":bin(50),
                  "3":bin(51),
                  "4":bin(52),
                  "5":bin(53),
                  "6":bin(54),
                  "7":bin(55),
                  "8":bin(56),
                  "9":bin(57),
                  ":":bin(58),
                  ";":bin(59),
                  "<":bin(60),
                  "=":bin(61),
                  ">":bin(62),
                  "?":bin(63),
                  "@":bin(64),
                  "A":bin(65),
                  "B":bin(66),
                  "C":bin(67),
                  "D":bin(68),
                  "E":bin(69),
                  "F":bin(70),
                  "G":bin(71),
                  "H":bin(72),
                  "I":bin(73),
                  "J":bin(74),
                  "K":bin(75),
                  "L":bin(76),
                  "M":bin(77),
                  "N":bin(78),
                  "O":bin(79),
                  "P":bin(80),
                  "Q":bin(81),
                  "R":bin(82),
                  "S":bin(83),
                  "T":bin(84),
                  "U":bin(85),
                  "V":bin(86),
                  "W":bin(87),
                  "X":bin(88),
                  "Y":bin(89),
                  "Z":bin(90),
                  "a":bin(97),
                  "b":bin(98),
                  "c":bin(99),
                  "d":bin(100),
                  "e":bin(101),
                  "f":bin(102),
                  "g":bin(103),
                  "h":bin(104),
                  "i":bin(105),
                  "j":bin(106),
                  "k":bin(107),
                  "l":bin(108),
                  "m":bin(109),
                  "n":bin(110),
                  "o":bin(111),
                  "p":bin(112),
                  "q":bin(113),
                  "r":bin(114),
                  "s":bin(115),
                  "t":bin(116),
                  "u":bin(117),
                  "v":bin(118),
                  "w":bin(119),
                  "x":bin(120),
                  "y":bin(121),
                  "z":bin(122)
                  }
            self.alphaBet = {
                  bin(33):"!",
                  bin(35):"#",
                  bin(36):"$",
                  bin(37):"%",
                  bin(38):"&",
                  bin(:42):"*",
                  bin(43):"+",
                  bin(44):",",
                  bin(45):"-",
                  bin(46):".",
                  bin(47):"/",
                  bin(48):"0",
                  bin(49):"1",
                  bin(50):"2",
                  bin(51):"3",
                  bin(52)"4",
                  bin(53):"5",
                  bin(54):"6",
                  bin(55):"7",
                  bin(56):"8",
                  bin(57):"9",
                  bin(58):":",
                  bin(59):";",
                  bin(60):"<",
                  bin(61):"=",
                  bin(62):">",
                  bin(63):"?",
                  bin(64):"@",
                  bin(65):"A",
                  bin(66):"B",
                  bin(67):"C",
                  bin(68):"D",
                  bin(69):"E",
                  bin(70):"F",
                  bin(71):"G",
                  bin(72):"H",
                  bin(73):"I",
                  bin(74):"J",
                  bin(75):"K",
                  bin(76):"L",
                  bin(77):"M",
                  bin(78):"N",
                  bin(79):"O",
                  bin(80):"P",
                  bin(81):"Q",
                  bin(82):"R",
                  bin(83):"S",
                  bin(84):"T",
                  bin(85):"U",
                  bin(86):"V",
                  bin(87):"W",
                  bin(88):"X",
                  bin(89):"Y",
                  bin(90):"Z",
                  bin(97):"a",
                  bin(98):"b",
                  bin(99):"c",
                  bin(100):"d",
                  bin(101):"e",
                  bin(102):"f",
                  bin(103):"g",
                  bin(104)"h",
                  bin(105):"i",
                  bin(106):"j",
                  bin(107):"k",
                  bin(108):"l",
                  bin(109):"m",
                  bin(110):"n",
                  bin(111):"o",
                  bin(112):"p",
                  bin(113):"q",
                  bin(114):"r",
                  bin(115):"s",
                  bin(116):"t",
                  bin(117):"u",
                  bin(118):"v",
                  bin(119):"w",
                  bin(120):"x",
                  bin(121):"y",
                  bin(122):"z"
                  }
            self.plainText = plainText
            self.ciphertext = ""
            self.spaceDef = []
            self.key = []
            self.pTL = []
            self.plainTextList  = []
            self.letterKey = ""
            self.FormatText()
      def FormatText(self):
            for x in self.plainText:
                  if x != " ":
                        self.pTL.append(x)
            self.createKey()
      def createKey(self):
            for x in range(0, len(self.pTL)):
                  self.key.append(random.randint(97,122))
            y = map(bin, self.key)
            self.key = y
            self.fullEncryption()
      def fullEncryption(self):
            self.spaceDef = self.spaceDefiner()
            nL = []
            for x in self.pTL:
                  nL.append(self.LCAlphaBet[x])
            r = []
            for x in range(0, len(0,nL)):
                  r.append(nL[x]^self.key[x])
            for x in range(0, len(r)):
                  if x not in spaceDef:
                        self.ciphertext += self.alphaBet[r[x]]
                  else:
                        self.ciphertext += " "
            for x in range(0, len(nL)):
                  if x not in spaceDef:
                        self.letterKey +=  self.alphaBet[nL[x]]
                  else:
                        self.ciphertext += " "              
            
            
            













                  
      
